/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poe;

/**
 *
 * @author Kaylee
 */

  import java.util.Scanner;

    public class Login {
 
        
         static account account = new account();
         
        

    
                //code attribution
                //This method was taken from Java Guides 
                //https://www.javaguides.net/2020/03/java-scanner-tutorial-reading-login-and-registration-user-input.html
                //Ramesh Fadatare
                //https://www.blogger.com/profile/14691512106162803120
         
         
         
         
        public static void main(String[]args){
            
            Scanner name =new Scanner(System.in);    /*Creates a new scanner*/
            
            System.out.println("Please Enter your first name "); /*Prompts user to enter their first name */
                String firstName;
                firstName =name.nextLine();
                    System.out.println("Hello"+" "+ firstName); /*Displays the users input*/
        
            
            
            System.out.println("Please Enter your last name "); /*Promts user to enter their Last name */
                 String lastName;
                 lastName =name.nextLine();
                    System.out.println("Hello"+" "+ firstName+" "+ lastName); /*Displays the users input*/
        
            
            
            
            System.out.println("Please create a user name that is 5 characters long and contains an underscore(_)");    /*Promts the user to enter their username*/
                 String userName;  /*Declares the variable userName*/
                 userName = name.nextLine();
                    boolean userValid = checkUserName(userName); /*Checks that the username meets the conditions set in checkUserName() and creates a new variable (userValid) to store the input from the user*/
            
                    
                    
            System.out.println("Please create a password that consists of 8 characters, ensure that it contains a capital letter, a number, as well as a special character");
                 String password;  /*Declares the variable userName*/
                 password = name.nextLine();
                    boolean passValid = checkPasswordComplexity(password); /*Checks that the username meets the conditions set in checkUserName() and creates a new variable (passValid) to store the input from the user */
            
            registerUser(userName, password);  /* Checks if the user can successfully register */
            if(userValid && passValid){   /*Takes stored values to determine the registration status*/
        
                account.setUserName(userName);
                account.setpassword (password);
                System.out.println("User has been registered successfully");
            }else{
                System.out.println("Username is incorrectly formatted or password does not meet the complexity");
                System.exit(0);
            }
            
            
            System.out.println("Please enter your username to log in");   /*User must enter credentials again to log in */
            String EnteredUserName = name.nextLine();
            
            System.out.println("Please enter your password to log in");
            String EnteredPassWord = name.nextLine();
            boolean loginAttempt = loginUser(EnteredUserName, EnteredPassWord );  /*Checks if new login detials enetered match those of the ones that we stored earlier */
            if (loginAttempt){
                account.setFirstName(firstName);
                account.setLastName(lastName);
                System.out.println("Welcome"+" "+ firstName +" "+ lastName+ " "+"it's great to see you again.");
            }else{
                System.out.println("Username or password incorrect, please try again.");
            }


            String showLoginStatus;
             showLoginStatus = returnLoginStatus(EnteredUserName,EnteredPassWord);
                    if (showLoginStatus.equals("success")){
                        System.out.println("Successful Login");
                        
                    } else {
                        System.out.println("Failed login");
             }
                
            
            
            
           
        }
        
        
        
            //code attribution
                //This method was taken from stack overflow 
                //https://stackoverflow.com/questions/72061438/how-do-i-run-a-method-boolean-checkusername-this-method-ensures-that-any-use
                //Will
                //https://stackoverflow.com/users/1727416/will
        
        
        

        public static boolean checkUserName(String userName){ /*Checks that the username provided by the user meets the conditions of being 5 charcaters long and containing an underscore */
            boolean underScore;
            underScore= userName.contains("_");
            if( underScore==true && userName.length()==5  ){   /*If statement is used to output a result for both true and false cases. if the conditions are met there is an output that will be displayed and the same if the conditions are not met the message for false will be output. The && ensures that BOTH conditions must be met for the result to be true if one condition is not met the output will be false */
            System.out.println("Username entered successfully"); /*Output message that will be displayed if conditions are met*/
                return true;
            }else {
                System.out.println("Invalid username"); /*Message that will be displayed if the conditions for the username are not met*/
            return false;
            }
                //code attribution
                //This method was taken from geeksforgeeks
                //https://www.geeksforgeeks.org/how-to-validate-a-password-using-regular-expressions-in-java/
                //Prashant Srivastava 
                //https://www.geeksforgeeks.org/user/prashant_srivastava/
       
        }
        
        
        public static boolean checkPasswordComplexity(String password){  /*Checks that the password entered by the user meets the conditions set for the password which is that it must contain 8 characters, a capital letter, a number and a special charcater*/
            boolean length; 
            boolean capital;
            boolean special; 
            boolean number;
            length= (password.length()>=8); /*Checks that the password contains exactly 8 characters*/
            capital= password.matches(".*[A-Z].*"); /*Checks that the password contains any capital letter from A to Z */
            special=password.matches(".*[<>?,/'{}\\[\\]=+\\-_()*!&@^#%$~`|].*"); /*Checks that the password contains a special character*/
            number=password.matches(".*[0-9].*"); /*Checks that the password contains any number from 0 to 9 */
            if ( length && capital && special && number){      /*If statement used to ensure that all the above conitions are met. && used to ensure that all conditions must be true for the password to be accpeted if one condition is false it will be unsuccessful*/
                System.out.println("Password successfully captured"); /*Output message that will be displayed if conditions are met*/
                return true;
            }else{
                System.out.println("Password is not correctly formatted. Please ensure that the password contains at least 8 characters, a capital letter, a number, and a special character."); /*Message that will be displayed if the conditions for the username are not met for example if the password is 9 charcaters long instead of 8*/
                return false;
            }
            
        
        }
       
        
        public static String registerUser(String userName  ,String password ){   /* registers the users input*/
            boolean userNameTrue = checkUserName( userName);   /*Checks that the username entered is the same username that the user created an account with in the account class*/
            boolean passwordTrue = checkPasswordComplexity(password);/*Checks that the password is the same as the one that the user created when creating an account in the account class */
                if (userNameTrue && passwordTrue){  /*sets the condition that both the username and password must be true*/
                    return "User has been registered successfully";
                  
                }else {
                    return "Username is incorrectly formatted or password does not meet the complexity";
                }  
            
            
    }
    
    
        public static boolean loginUser( String userName,String password){   /*Allows the user to log in*/
             
            if (account.getuserName().equals(userName) && account.getpassword().equals(password)){  /*The username and password must BOTH be correct for the user to successfully log in*/
               
                //System.out.println("Welcome"+ account.getFirstName() +" "+ account.getLastName()+ "it's great to see you again.");
                return true;
            }else{
                //System.out.println("Username or password incorrect, please try again.");
                return false;
        }
        
    }  
        
        
        
        public static String returnLoginStatus(String userName,String password){ /*Outputs if the user was successfull in logging in*/
            
            boolean success = loginUser( userName, password);
             
           
            if (success) {
                
                return "successful login"; /*Output message if login was successful*/
                
            }
            else{
                
                return "failed log in"; /*Output message if login was unsuccessful*/
                
            }
            
            
            
}

    }
