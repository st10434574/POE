/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poe;



/**
 *
 * @author Kaylee
 */

 


public class account {
    
  static String firstName;
  static String lastName;
  static String userName;
  static String password;
    private String firstname;
    private String lastname;
  
  
    
    
    
    
    public String getuserName( ){
        return userName;
    }
    public void setUserName(String username){
    userName = username;
    }
    
    
    public String getpassword() {
        return password;  
    }
    public void setpassword(String passWord){
        password =passWord;
        
            
    }

    public String getFirstName() {
        return firstName;
        
}
    public void setFirstName(String firstName){
         firstName= firstname;
    }
    

    public String getLastName() {
        return lastName;
       
    }
    
    public void setLastName(String lastName ){
        lastName= lastname;
}
}

    
 

    














    

