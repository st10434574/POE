/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package poe;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Kaylee
 */
public class LoginTest {
    
    public LoginTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of checkUserName method, of class Login.
     */
    @Test
    public void testCheckUserName() {
        System.out.println("checkUserName");
        String userName = "kyl_1";
        boolean expResult = true;
        boolean result = Login.checkUserName(userName);
        assertEquals(expResult, result);
    }   
       public void testCheckUserNameFalse() {
        System.out.println("checkUserName");
        String userName = "kyle!!!!!!!";
        boolean expResult = false;
        boolean result = Login.checkUserName(userName);
        assertEquals(expResult, result);
          
        
       
    }

       
       
       
       
    /**
     * Test of checkPasswordComplexity method, of class Login.
     */
    @Test
    public void testCheckPasswordComplexity() {
        System.out.println("checkPasswordComplexity");
        String password = "Ch**sec@ke99";
        boolean expResult = true;
        boolean result = Login.checkPasswordComplexity(password);
        assertEquals(expResult, result);
        
        
        
        
    }  
    public void testCheckPasswordComplexityFalse() {
        System.out.println("checkPasswordComplexity");
        String password = "password";
        boolean expResult = false;
        boolean result = Login.checkPasswordComplexity(password);
        assertEquals(expResult, result);
       

    }

    /**
     * Test of loginUser method, of class Login.
     */
    @Test
    public void testLoginUser() {
        System.out.println("loginUser");
        String userName = "kyl_1";
        String password = "Ch&&sec@ke99!";
        boolean expResult = false;
        boolean result = Login.loginUser(userName, password);
        assertEquals(expResult, result);
     
  
       
    }


    
    
}
